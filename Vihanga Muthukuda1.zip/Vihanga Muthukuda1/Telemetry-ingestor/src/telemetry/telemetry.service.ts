// src/telemetry/telemetry.service.ts
import { Injectable, Logger } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Telemetry } from './schemas/telemetry.schema';
import { TelemetryDto } from './dto/telemetry.dto';
import Redis from 'ioredis';
import { ConfigService } from '@nestjs/config';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom } from 'rxjs';

interface Alert {
  deviceId: string;
  siteId: string;
  ts: string;
  reason: string;
  value: number;
}

@Injectable()
export class TelemetryService {
  private readonly logger = new Logger(TelemetryService.name);
  private readonly redis: Redis;
  private readonly alertCache: Set<string> = new Set();

  constructor(
    @InjectModel(Telemetry.name) private telemetryModel: Model<Telemetry>,
    private configService: ConfigService,
    private httpService: HttpService,
  ) {
    const redisUrl = this.configService.get<string>('REDIS_URL') || 'redis://localhost:6379';
    this.redis = new Redis(redisUrl, {
      retryStrategy: (times) => Math.min(times * 50, 2000),
      maxRetriesPerRequest: 3,
    });

    this.redis.on('error', (err) => {
      this.logger.error(`Redis connection error: ${err.message}`);
    });

    this.redis.on('connect', () => {
      this.logger.log('Redis connected successfully');
    });

    // Clear alert cache every 60 seconds for deduplication
    setInterval(() => {
      const size = this.alertCache.size;
      this.alertCache.clear();
      this.logger.debug(`Alert cache cleared. Previous size: ${size}`);
    }, 60000);
  }

  async ingest(data: TelemetryDto | TelemetryDto[]): Promise<void> {
    const readings = Array.isArray(data) ? data : [data];
    this.logger.log(`Ingesting ${readings.length} telemetry reading(s)`);

    for (const reading of readings) {
      try {
        // Persist to MongoDB
        const telemetry = new this.telemetryModel({
          ...reading,
          ts: new Date(reading.ts),
        });
        await telemetry.save();

        // Cache latest in Redis with 24h TTL
        const cacheKey = `latest:${reading.deviceId}`;
        await this.redis.set(cacheKey, JSON.stringify(reading), 'EX', 86400);

        this.logger.log(`Ingested telemetry for device: ${reading.deviceId}`);

        // Check and send alerts
        await this.checkAlerts(reading);
      } catch (error) {
        this.logger.error(
          `Failed to ingest telemetry for device ${reading.deviceId}: ${error.message}`,
          error.stack,
        );
        throw error;
      }
    }
  }

  private async checkAlerts(reading: TelemetryDto): Promise<void> {
    const alerts: Alert[] = [];

    if (reading.metrics.temperature > 50) {
      alerts.push({
        deviceId: reading.deviceId,
        siteId: reading.siteId,
        ts: reading.ts,
        reason: 'HIGH_TEMPERATURE',
        value: reading.metrics.temperature,
      });
    }

    if (reading.metrics.humidity > 90) {
      alerts.push({
        deviceId: reading.deviceId,
        siteId: reading.siteId,
        ts: reading.ts,
        reason: 'HIGH_HUMIDITY',
        value: reading.metrics.humidity,
      });
    }

    for (const alert of alerts) {
      // Deduplication: check if alert was sent in last 60s
      const dedupKey = `${alert.deviceId}:${alert.reason}`;
      if (this.alertCache.has(dedupKey)) {
        this.logger.debug(`Alert deduplicated: ${dedupKey}`);
        continue;
      }

      await this.sendAlert(alert);
      this.alertCache.add(dedupKey);
    }
  }

  private async sendAlert(alert: Alert): Promise<void> {
    const webhookUrl = this.configService.get<string>('ALERT_WEBHOOK_URL');
    if (!webhookUrl) {
      this.logger.warn('No ALERT_WEBHOOK_URL configured, skipping alert');
      return;
    }

    try {
      await firstValueFrom(
        this.httpService.post(webhookUrl, alert, {
          timeout: 5000,
          headers: { 'Content-Type': 'application/json' },
        }),
      );
      this.logger.log(
        `Alert sent for device ${alert.deviceId}: ${alert.reason} (value: ${alert.value})`,
      );
    } catch (error: any) {
      this.logger.error(`Failed to send alert: ${error.message}`);
    }
  }

  async getLatest(deviceId: string): Promise<TelemetryDto | null> {
    try {
      // Try Redis first
      const cached = await this.redis.get(`latest:${deviceId}`);
      if (cached) {
        this.logger.debug(`Cache HIT for device: ${deviceId}`);
        return JSON.parse(cached);
      }

      // Fallback to MongoDB
      this.logger.debug(`Cache MISS for device: ${deviceId}, querying MongoDB`);
      const latest = await this.telemetryModel
        .findOne({ deviceId })
        .sort({ ts: -1 })
        .lean()
        .exec();

      if (latest) {
        const result = {
          deviceId: latest.deviceId,
          siteId: latest.siteId,
          ts: latest.ts.toISOString(),
          metrics: latest.metrics,
        };
        
        // Update cache for next time
        await this.redis.set(
          `latest:${deviceId}`,
          JSON.stringify(result),
          'EX',
          86400,
        );
        return result;
      }

      return null;
    } catch (error: any) {
      this.logger.error(
        `Failed to get latest for device ${deviceId}: ${error.message}`,
        error.stack,
      );
      throw error;
    }
  }

  async getSiteSummary(
    siteId: string,
    from: string,
    to: string,
  ): Promise<any> {
    try {
      this.logger.log(`Getting summary for site ${siteId} from ${from} to ${to}`);
      
      const result = await this.telemetryModel.aggregate([
        {
          $match: {
            siteId,
            ts: {
              $gte: new Date(from),
              $lte: new Date(to),
            },
          },
        },
        {
          $group: {
            _id: null,
            count: { $sum: 1 },
            avgTemperature: { $avg: '$metrics.temperature' },
            maxTemperature: { $max: '$metrics.temperature' },
            avgHumidity: { $avg: '$metrics.humidity' },
            maxHumidity: { $max: '$metrics.humidity' },
            uniqueDevices: { $addToSet: '$deviceId' },
          },
        },
        {
          $project: {
            _id: 0,
            count: 1,
            avgTemperature: { $round: ['$avgTemperature', 2] },
            maxTemperature: 1,
            avgHumidity: { $round: ['$avgHumidity', 2] },
            maxHumidity: 1,
            uniqueDevices: { $size: '$uniqueDevices' },
          },
        },
      ]);

      return result[0] || {
        count: 0,
        avgTemperature: 0,
        maxTemperature: 0,
        avgHumidity: 0,
        maxHumidity: 0,
        uniqueDevices: 0,
      };
    } catch (error: any) {
      this.logger.error(
        `Failed to get summary for site ${siteId}: ${error.message}`,
        error.stack,
      );
      throw error;
    }
  }

  async checkHealth(): Promise<{ mongo: boolean; redis: boolean }> {
    const health = { mongo: false, redis: false };

    try {
      if (this.telemetryModel.db?.db) {
        await this.telemetryModel.db.db.admin().ping();
        health.mongo = true;
        this.logger.debug('MongoDB health check: OK');
      }
    } catch (error: any) {
      this.logger.error(`MongoDB health check failed: ${error.message}`);
    }

    try {
      const result = await this.redis.ping();
      health.redis = result === 'PONG';
      this.logger.debug('Redis health check: OK');
    } catch (error: any) {
      this.logger.error(`Redis health check failed: ${error.message}`);
    }

    return health;
  }
}