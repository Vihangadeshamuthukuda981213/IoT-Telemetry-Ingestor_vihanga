import { Test, TestingModule } from '@nestjs/testing';
import { TelemetryService } from './telemetry.service';
import { getModelToken } from '@nestjs/mongoose';
import { Telemetry } from './schemas/telemetry.schema';
import { ConfigService } from '@nestjs/config';
import { HttpService } from '@nestjs/axios';
import { of } from 'rxjs';

describe('TelemetryService', () => {
  let service: TelemetryService;
  let mockTelemetryModel: any;
  let mockHttpService: any;

  beforeEach(async () => {
    mockTelemetryModel = {
      create: jest.fn(),
      findOne: jest.fn(),
      aggregate: jest.fn(),
      db: { db: { admin: () => ({ ping: jest.fn().mockResolvedValue(true) }) } },
    };

    mockHttpService = {
      post: jest.fn().mockReturnValue(of({ data: {} })),
    };

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        TelemetryService,
        {
          provide: getModelToken(Telemetry.name),
          useValue: mockTelemetryModel,
        },
        {
          provide: ConfigService,
          useValue: {
            get: jest.fn((key: string) => {
              if (key === 'REDIS_URL') return 'redis://localhost:6379';
              if (key === 'ALERT_WEBHOOK_URL') return 'https://webhook.site/test';
              return null;
            }),
          },
        },
        {
          provide: HttpService,
          useValue: mockHttpService,
        },
      ],
    }).compile();

    service = module.get<TelemetryService>(TelemetryService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  // Add more tests here
});