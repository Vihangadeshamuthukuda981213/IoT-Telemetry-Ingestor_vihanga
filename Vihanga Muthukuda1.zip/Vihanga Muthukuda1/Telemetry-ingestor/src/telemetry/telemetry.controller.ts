import {
  Controller,
  Post,
  Get,
  Body,
  Param,
  Query,
  UseGuards,
  HttpCode,
  HttpStatus,
  UsePipes,
  ValidationPipe,
  BadRequestException,
} from '@nestjs/common';
import { TelemetryService } from './telemetry.service';
import { TelemetryDto } from './dto/telemetry.dto';
import { AuthGuard } from '../guards/auth.guard';

@Controller('api/v1')
@UsePipes(new ValidationPipe({ transform: true, whitelist: true }))
export class TelemetryController {
  constructor(private readonly telemetryService: TelemetryService) {}

  @Post('telemetry')
  @UseGuards(AuthGuard)
  @HttpCode(HttpStatus.CREATED)
  async ingest(@Body() data: TelemetryDto | TelemetryDto[]) {
    await this.telemetryService.ingest(data);
    
    const count = Array.isArray(data) ? data.length : 1;
    
    return { 
      success: true, 
      message: 'Telemetry ingested',
      count 
    };
  }

  @Get('devices/:deviceId/latest')
  async getLatest(@Param('deviceId') deviceId: string) {
    const data = await this.telemetryService.getLatest(deviceId);
    return data || { message: 'No data found' };
  }

  @Get('sites/:siteId/summary')
  async getSummary(
    @Param('siteId') siteId: string,
    @Query('from') from: string,
    @Query('to') to: string,
  ) {
    if (!from || !to) {
      throw new BadRequestException('from and to query parameters are required');
    }

    const fromDate = new Date(from);
    const toDate = new Date(to);
    
    if (isNaN(fromDate.getTime()) || isNaN(toDate.getTime())) {
      throw new BadRequestException('from and to must be valid ISO 8601 date strings');
    }

    return this.telemetryService.getSiteSummary(siteId, from, to);
  }
}
