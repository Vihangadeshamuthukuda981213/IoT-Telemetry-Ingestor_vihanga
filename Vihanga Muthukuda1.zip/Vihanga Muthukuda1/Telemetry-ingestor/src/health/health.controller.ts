import { Controller, Get } from '@nestjs/common';
import { TelemetryService } from '../telemetry/telemetry.service';

@Controller('health')
export class HealthController {
  constructor(private readonly telemetryService: TelemetryService) {}

  @Get()
  async check() {
    const health = await this.telemetryService.checkHealth();
    const status = health.mongo && health.redis ? 'healthy' : 'unhealthy';
    
    return {
      status,
      mongo: health.mongo,
      redis: health.redis,
    };
  }
}
