import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication, ValidationPipe } from '@nestjs/common';
import { AppModule } from './../src/app.module';

// Use require instead of import for supertest
const request = require('supertest');

describe('TelemetryController (e2e)', () => {
  let app: INestApplication;
  let httpServer: any;

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    
    app.useGlobalPipes(
      new ValidationPipe({
        whitelist: true,
        forbidNonWhitelisted: true,
        transform: true,
      }),
    );
    
    await app.init();
    httpServer = app.getHttpServer();
  });

  afterAll(async () => {
    if (app) await app.close();
  });

  describe('POST /api/v1/telemetry', () => {
    it('should successfully ingest valid telemetry data', async () => {
      const response = await request(httpServer)
        .post('/api/v1/telemetry')
        .set('Authorization', 'Bearer secret123')
        .send({
          deviceId: 'dev-test-001',
          siteId: 'site-test-A',
          ts: new Date().toISOString(),
          metrics: { temperature: 25.5, humidity: 60 },
        })
        .expect(201);

      expect(response.body).toHaveProperty('success', true);
      expect(response.body).toHaveProperty('message');
      expect(response.body).toHaveProperty('count', 1);
    });

    it('should ingest batch telemetry data', async () => {
      const response = await request(httpServer)
        .post('/api/v1/telemetry')
        .set('Authorization', 'Bearer secret123')
        .send([
          {
            deviceId: 'dev-batch-001',
            siteId: 'site-test-A',
            ts: new Date().toISOString(),
            metrics: { temperature: 22.0, humidity: 55 },
          },
          {
            deviceId: 'dev-batch-002',
            siteId: 'site-test-A',
            ts: new Date().toISOString(),
            metrics: { temperature: 23.5, humidity: 58 },
          },
        ])
        .expect(201);

      expect(response.body).toHaveProperty('success', true);
      expect(response.body).toHaveProperty('count', 2);
    });

    it('should trigger alert for high temperature', async () => {
      await request(httpServer)
        .post('/api/v1/telemetry')
        .set('Authorization', 'Bearer secret123')
        .send({
          deviceId: 'dev-hot-e2e',
          siteId: 'site-test-A',
          ts: new Date().toISOString(),
          metrics: { temperature: 55.0, humidity: 60 },
        })
        .expect(201);
    });

    it('should reject invalid data - missing siteId', async () => {
      await request(httpServer)
        .post('/api/v1/telemetry')
        .set('Authorization', 'Bearer secret123')
        .send({
          deviceId: 'dev-001',
          ts: new Date().toISOString(),
          metrics: { temperature: 25.0, humidity: 60 },
        })
        .expect(400);
    });

    it('should reject invalid data - invalid temperature type', async () => {
      await request(httpServer)
        .post('/api/v1/telemetry')
        .set('Authorization', 'Bearer secret123')
        .send({
          deviceId: 'dev-001',
          siteId: 'site-A',
          ts: new Date().toISOString(),
          metrics: { temperature: 'not-a-number', humidity: 60 },
        })
        .expect(400);
    });

    it('should reject invalid ISO timestamp', async () => {
      await request(httpServer)
        .post('/api/v1/telemetry')
        .set('Authorization', 'Bearer secret123')
        .send({
          deviceId: 'dev-001',
          siteId: 'site-A',
          ts: 'invalid-date',
          metrics: { temperature: 25.0, humidity: 60 },
        })
        .expect(400);
    });

    it('should reject request without authorization header', async () => {
      await request(httpServer)
        .post('/api/v1/telemetry')
        .send({
          deviceId: 'dev-001',
          siteId: 'site-A',
          ts: new Date().toISOString(),
          metrics: { temperature: 25.0, humidity: 60 },
        })
        .expect(401);
    });

    it('should reject request with invalid token', async () => {
      await request(httpServer)
        .post('/api/v1/telemetry')
        .set('Authorization', 'Bearer wrong-token')
        .send({
          deviceId: 'dev-001',
          siteId: 'site-A',
          ts: new Date().toISOString(),
          metrics: { temperature: 25.0, humidity: 60 },
        })
        .expect(401);
    });
  });

  describe('GET /api/v1/devices/:deviceId/latest', () => {
    beforeAll(async () => {
      await request(httpServer)
        .post('/api/v1/telemetry')
        .set('Authorization', 'Bearer secret123')
        .send({
          deviceId: 'dev-latest-test',
          siteId: 'site-test-A',
          ts: new Date().toISOString(),
          metrics: { temperature: 28.5, humidity: 62 },
        });

      await new Promise((resolve) => setTimeout(resolve, 1000));
    });

    it('should return latest reading for device', async () => {
      const response = await request(httpServer)
        .get('/api/v1/devices/dev-latest-test/latest')
        .expect(200);

      expect(response.body).toHaveProperty('deviceId', 'dev-latest-test');
      expect(response.body).toHaveProperty('siteId');
      expect(response.body).toHaveProperty('metrics');
    });

    it('should return message for non-existent device', async () => {
      const response = await request(httpServer)
        .get('/api/v1/devices/non-existent-device/latest')
        .expect(200);

      expect(response.body).toHaveProperty('message');
    });
  });

  describe('GET /api/v1/sites/:siteId/summary', () => {
    beforeAll(async () => {
      const readings = [
        {
          deviceId: 'dev-summary-001',
          siteId: 'site-summary-test',
          ts: '2025-10-31T10:00:00.000Z',
          metrics: { temperature: 25.0, humidity: 60 },
        },
        {
          deviceId: 'dev-summary-002',
          siteId: 'site-summary-test',
          ts: '2025-10-31T11:00:00.000Z',
          metrics: { temperature: 30.0, humidity: 65 },
        },
        {
          deviceId: 'dev-summary-003',
          siteId: 'site-summary-test',
          ts: '2025-10-31T12:00:00.000Z',
          metrics: { temperature: 28.0, humidity: 70 },
        },
      ];

      for (const reading of readings) {
        await request(httpServer)
          .post('/api/v1/telemetry')
          .set('Authorization', 'Bearer secret123')
          .send(reading);
      }

      await new Promise((resolve) => setTimeout(resolve, 1500));
    });

    it('should return aggregated summary for site', async () => {
      const response = await request(httpServer)
        .get('/api/v1/sites/site-summary-test/summary')
        .query({
          from: '2025-10-31T00:00:00.000Z',
          to: '2025-11-01T00:00:00.000Z',
        })
        .expect(200);

      expect(response.body.count).toBeGreaterThan(0);
      expect(response.body.avgTemperature).toBeDefined();
      expect(response.body.maxTemperature).toBeDefined();
      expect(response.body.avgHumidity).toBeDefined();
      expect(response.body.maxHumidity).toBeDefined();
      expect(response.body.uniqueDevices).toBeGreaterThan(0);
    });

    it('should return empty summary for site with no data', async () => {
      const response = await request(httpServer)
        .get('/api/v1/sites/non-existent-site/summary')
        .query({
          from: '2025-10-31T00:00:00.000Z',
          to: '2025-11-01T00:00:00.000Z',
        })
        .expect(200);

      expect(response.body.count).toBe(0);
    });

    it('should reject request without from parameter', async () => {
      await request(httpServer)
        .get('/api/v1/sites/site-test-A/summary')
        .query({ to: '2025-11-01T00:00:00.000Z' })
        .expect(400);
    });

    it('should reject request without to parameter', async () => {
      await request(httpServer)
        .get('/api/v1/sites/site-test-A/summary')
        .query({ from: '2025-10-31T00:00:00.000Z' })
        .expect(400);
    });

    it('should reject invalid date format', async () => {
      await request(httpServer)
        .get('/api/v1/sites/site-test-A/summary')
        .query({
          from: 'invalid-date',
          to: '2025-11-01T00:00:00.000Z',
        })
        .expect(400);
    });
  });

  describe('GET /health', () => {
    it('should return health status', async () => {
      const response = await request(httpServer)
        .get('/health')
        .expect(200);

      expect(response.body).toHaveProperty('status');
      expect(response.body).toHaveProperty('mongo');
      expect(response.body).toHaveProperty('redis');
    });
  });
});